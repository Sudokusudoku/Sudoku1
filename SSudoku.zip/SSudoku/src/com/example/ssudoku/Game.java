package com.example.ssudoku;

public class Game {

	private String str="360000000004230800000004200"
			+"070460003820000014500013020"
			+"001900000007048300000000045";

	private int sudoku[] = new int[9*9];
	public static int i;

	public Game(){
		sudoku=getProblemString(str);
	}

	public int getNumber(String s){
		
		i=s.charAt(0)-'0';
		return i;
	}


	public int[] getProblemString(String s) {
		int[] sudo = new int[s.length()];
		for(int i=0;i<s.length();i++){
			sudo[i]=s.charAt(i)- '0';
		}

		return sudo;

	}

	public int getTile(int x,int y){
		return sudoku[y*9+x];
	}

	public String getTileString(int x,int y){
		int num=getTile(x, y);
		if( num == 0)
			return "";
		else {
			return String.valueOf(num);

		}
	}
	
	public void setTile(int x, int y){
		sudoku[y*9 + x] = i;
	}
}
