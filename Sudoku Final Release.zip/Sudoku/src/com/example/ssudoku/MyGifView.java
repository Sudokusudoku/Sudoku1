package com.example.ssudoku;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Movie;
import android.util.AttributeSet;
import android.view.View;

public class MyGifView extends View{

	private long movieStart;
	private Movie movie;
	
	public MyGifView(Context context,AttributeSet attributeSet) {
		super(context,attributeSet);
		movie=Movie.decodeStream(getResources().openRawResource(R.drawable.beargif));

	}

	@Override
	protected void onDraw(Canvas canvas) {

		long curTime=android.os.SystemClock.uptimeMillis();
		if (movieStart == 0) {
			movieStart = curTime;
		}

		if (movie != null) {
			int duraction = movie.duration();
			int relTime = (int) ((curTime-movieStart)%duraction);
			movie.setTime(relTime);
			movie.draw(canvas, 0, 0);
			invalidate();
		}

		super.onDraw(canvas);
	}

}

